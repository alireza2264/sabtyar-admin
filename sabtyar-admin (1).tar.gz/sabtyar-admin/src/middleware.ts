import { NextRequest, NextResponse } from "next/server";

export function middleware(req: NextRequest) {
  const session = req.cookies.get("admin_session");
  const isLogin = req.nextUrl.pathname === "/login";
  const isApiAuth = req.nextUrl.pathname === "/api/auth";
  const isApiLeadsPost = req.nextUrl.pathname === "/api/leads" && req.method === "POST";

  // Allow login page, auth API, and public lead submission
  if (isLogin || isApiAuth || isApiLeadsPost) {
    return NextResponse.next();
  }

  // Protect all other routes
  if (!session) {
    if (req.nextUrl.pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    return NextResponse.redirect(new URL("/login", req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
