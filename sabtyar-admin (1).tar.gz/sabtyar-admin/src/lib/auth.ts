// Simple auth for demo - change password in production
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "sabtyar1404";

export function verifyPassword(password: string): boolean {
  return password === ADMIN_PASSWORD;
}

export function createSessionToken(): string {
  return Buffer.from(`admin:${Date.now()}:${Math.random()}`).toString("base64");
}
