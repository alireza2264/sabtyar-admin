export type LeadStatus = "new" | "contacted" | "in_progress" | "closed" | "spam";

export interface Lead {
  id: string;
  name: string;
  phone: string;
  email?: string;
  service: string;
  message?: string;
  status: LeadStatus;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

// In-memory store (for demo). Replace with database in production.
let leads: Lead[] = [
  {
    id: "1",
    name: "علی محمدی",
    phone: "09121234567",
    email: "ali@example.com",
    service: "ثبت شرکت",
    message: "می‌خواهم شرکت با مسئولیت محدود ثبت کنم",
    status: "new",
    notes: "",
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
  },
  {
    id: "2",
    name: "سارا احمدی",
    phone: "09129876543",
    service: "ثبت برند",
    message: "ثبت علامت تجاری فارسی و لاتین",
    status: "contacted",
    notes: "تماس گرفته شد، مدارک ارسال می‌کند",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
  },
  {
    id: "3",
    name: "رضا کریمی",
    phone: "09351234567",
    email: "reza@company.ir",
    service: "حسابداری و مالیات",
    message: "نیاز به اظهارنامه عملکرد و سامانه مودیان",
    status: "in_progress",
    notes: "پرونده در حال تکمیل",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
  },
  {
    id: "4",
    name: "مریم حسینی",
    phone: "09131112233",
    service: "کارت بازرگانی",
    status: "new",
    notes: "",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
  },
  {
    id: "5",
    name: "حسین نوری",
    phone: "09221234567",
    service: "مجوز کسب‌وکار",
    message: "پروانه کسب صنفی",
    status: "closed",
    notes: "پرونده تکمیل و تحویل شد",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
  },
];

export function getLeads(): Lead[] {
  return [...leads].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export function getLead(id: string): Lead | undefined {
  return leads.find((l) => l.id === id);
}

export function addLead(data: Omit<Lead, "id" | "status" | "notes" | "createdAt" | "updatedAt">): Lead {
  const now = new Date().toISOString();
  const lead: Lead = {
    ...data,
    id: String(Date.now()),
    status: "new",
    notes: "",
    createdAt: now,
    updatedAt: now,
  };
  leads.unshift(lead);
  return lead;
}

export function updateLead(
  id: string,
  updates: Partial<Pick<Lead, "status" | "notes" | "name" | "phone" | "email" | "service" | "message">>
): Lead | null {
  const idx = leads.findIndex((l) => l.id === id);
  if (idx === -1) return null;
  leads[idx] = {
    ...leads[idx],
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  return leads[idx];
}

export function deleteLead(id: string): boolean {
  const before = leads.length;
  leads = leads.filter((l) => l.id !== id);
  return leads.length < before;
}

export function getStats() {
  const all = getLeads();
  return {
    total: all.length,
    new: all.filter((l) => l.status === "new").length,
    contacted: all.filter((l) => l.status === "contacted").length,
    in_progress: all.filter((l) => l.status === "in_progress").length,
    closed: all.filter((l) => l.status === "closed").length,
  };
}
