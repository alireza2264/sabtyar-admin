"use client";

import { useState } from "react";
import AdminLayout from "@/components/AdminLayout";
import { Save, Image as ImageIcon } from "lucide-react";

const initialContent = {
  heroTitle: "ثبت شرکت، برند و خدمات حسابداری",
  heroSubtitle: "ثبت یار هوشمند از ثبت شرکت و اخذ مجوز تا اظهارنامه، سامانه مودیان و دفاتر قانونی الکترونیک، پرونده شما را منظم و شفاف پیش می‌برد.",
  statsCustomers: "۱۲۰۰+",
  statsSuccess: "۹۸٪",
  statsExperience: "۱۰+",
  aboutText: "با بیش از یک دهه تجربه، ثبت شرکت و برند را به خدمات حسابداری، اظهارنامه عملکرد، سامانه مودیان و دفاتر قانونی الکترونیک متصل کرده‌ایم تا پس از ثبت، امور مالی مجموعه هم بدون وقفه پیش برود.",
  companyPrice: "از ۸٫۵۰۰٫۰۰۰ تومان",
  brandPrice: "از ۱۰٫۸۰۰٫۰۰۰ تومان",
  commercePrice: "از ۱۲٫۰۰۰٫۰۰۰ تومان",
  phone1: "۰۹۱۲۳۰۰۳۸۴۶",
  phone2: "۰۹۱۲۲۵۹۷۷۱۸",
  address: "تهران، جردن",
  workHours: "شنبه تا چهارشنبه ۸:۳۰–۱۷:۳۰",
};

export default function ContentPage() {
  const [content, setContent] = useState(initialContent);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  function update(key: keyof typeof content, value: string) {
    setContent((prev) => ({ ...prev, [key]: value }));
    setSaved(false);
  }

  async function handleSave() {
    setSaving(true);
    await new Promise((r) => setTimeout(r, 600));
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  const fields: { key: keyof typeof content; label: string; multiline?: boolean }[] = [
    { key: "heroTitle", label: "عنوان اصلی (Hero)" },
    { key: "heroSubtitle", label: "توضیح زیر عنوان", multiline: true },
    { key: "statsCustomers", label: "آمار مشتریان" },
    { key: "statsSuccess", label: "درصد موفقیت" },
    { key: "statsExperience", label: "سال تجربه" },
    { key: "aboutText", label: "متن درباره ما", multiline: true },
    { key: "companyPrice", label: "قیمت ثبت شرکت" },
    { key: "brandPrice", label: "قیمت ثبت برند" },
    { key: "commercePrice", label: "قیمت کارت بازرگانی" },
    { key: "phone1", label: "شماره تماس ۱" },
    { key: "phone2", label: "شماره تماس ۲" },
    { key: "address", label: "آدرس" },
    { key: "workHours", label: "ساعات کاری" },
  ];

  return (
    <AdminLayout>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-navy">محتوای سایت</h1>
          <p className="text-slate-500 mt-1">ویرایش متن‌ها و اطلاعات نمایشی سایت</p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 bg-navy hover:bg-slate-800 text-white px-5 py-2.5 rounded-xl text-sm font-medium transition disabled:opacity-60"
        >
          <Save size={16} />
          {saving ? "در حال ذخیره..." : saved ? "ذخیره شد ✓" : "ذخیره تغییرات"}
        </button>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 text-sm text-amber-800">
        <strong>توجه:</strong> برای اعمال تغییرات روی سایت اصلی، باید API محتوای سایت را به این پنل متصل کنید. در حال حاضر تغییرات فقط در پنل ذخیره می‌شوند (نسخه نمایشی).
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 space-y-5">
        {fields.map((f) => (
          <div key={f.key}>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">{f.label}</label>
            {f.multiline ? (
              <textarea
                value={content[f.key]}
                onChange={(e) => update(f.key, e.target.value)}
                rows={3}
                className="w-full px-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-gold/40 resize-none"
              />
            ) : (
              <input
                type="text"
                value={content[f.key]}
                onChange={(e) => update(f.key, e.target.value)}
                className="w-full px-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-gold/40"
              />
            )}
          </div>
        ))}
      </div>

      <div className="mt-8 bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
        <h2 className="font-semibold text-navy mb-4 flex items-center gap-2">
          <ImageIcon size={18} />
          مدیریت تصاویر
        </h2>
        <p className="text-sm text-slate-500 mb-4">
          تصاویر سایت در پوشه /images/ قرار دارند. برای تغییر، فایل‌های جدید را در همان مسیر آپلود کنید.
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {["hero-law.jpg", "company.jpg", "brand.jpg", "office.jpg", "accounting.jpg", "tax.jpg", "invoice.jpg", "about-team.jpg"].map((img) => (
            <div key={img} className="aspect-video bg-slate-100 rounded-xl flex items-center justify-center text-xs text-slate-400 border border-slate-200">
              {img}
            </div>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
}
