"use client";

import { useEffect, useState } from "react";
import AdminLayout from "@/components/AdminLayout";
import { Search, Filter, Phone, Mail, MessageSquare, Trash2, Save } from "lucide-react";
import { formatDate, formatRelative, cn } from "@/lib/utils";

interface Lead {
  id: string;
  name: string;
  phone: string;
  email?: string;
  service: string;
  message?: string;
  status: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

const statusOptions = [
  { value: "new", label: "جدید", color: "bg-blue-100 text-blue-700" },
  { value: "contacted", label: "تماس گرفته شده", color: "bg-amber-100 text-amber-700" },
  { value: "in_progress", label: "در حال پیگیری", color: "bg-purple-100 text-purple-700" },
  { value: "closed", label: "بسته شده", color: "bg-green-100 text-green-700" },
  { value: "spam", label: "اسپم", color: "bg-red-100 text-red-700" },
];

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selected, setSelected] = useState<Lead | null>(null);
  const [editNotes, setEditNotes] = useState("");
  const [editStatus, setEditStatus] = useState("");
  const [saving, setSaving] = useState(false);

  function loadLeads() {
    fetch("/api/leads")
      .then((r) => r.json())
      .then((data) => {
        setLeads(data);
        setLoading(false);
      });
  }

  useEffect(() => {
    loadLeads();
  }, []);

  function openLead(lead: Lead) {
    setSelected(lead);
    setEditNotes(lead.notes || "");
    setEditStatus(lead.status);
  }

  async function saveLead() {
    if (!selected) return;
    setSaving(true);
    const res = await fetch(`/api/leads/${selected.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ notes: editNotes, status: editStatus }),
    });
    if (res.ok) {
      const updated = await res.json();
      setLeads((prev) => prev.map((l) => (l.id === updated.id ? updated : l)));
      setSelected(updated);
    }
    setSaving(false);
  }

  async function deleteLead(id: string) {
    if (!confirm("آیا مطمئن هستید؟")) return;
    await fetch(`/api/leads/${id}`, { method: "DELETE" });
    setLeads((prev) => prev.filter((l) => l.id !== id));
    setSelected(null);
  }

  const filtered = leads.filter((l) => {
    const matchSearch =
      !search ||
      l.name.includes(search) ||
      l.phone.includes(search) ||
      l.service.includes(search) ||
      (l.email && l.email.includes(search));
    const matchStatus = statusFilter === "all" || l.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <AdminLayout>
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-navy">درخواست‌ها</h1>
          <p className="text-slate-500 mt-1">{leads.length} درخواست ثبت‌شده</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 mb-6 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="جستجو بر اساس نام، تلفن یا خدمت..."
            className="w-full pr-10 pl-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-gold/40 text-sm"
          />
        </div>
        <div className="relative">
          <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="pr-9 pl-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-gold/40 text-sm appearance-none bg-white min-w-[160px]"
          >
            <option value="all">همه وضعیت‌ها</option>
            {statusOptions.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* List */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          {loading ? (
            <div className="p-12 text-center text-slate-400">در حال بارگذاری...</div>
          ) : filtered.length === 0 ? (
            <div className="p-12 text-center text-slate-400">درخواستی یافت نشد</div>
          ) : (
            <div className="divide-y divide-slate-50 max-h-[70vh] overflow-y-auto">
              {filtered.map((lead) => {
                const st = statusOptions.find((s) => s.value === lead.status);
                return (
                  <button
                    key={lead.id}
                    onClick={() => openLead(lead)}
                    className={cn(
                      "w-full text-right px-5 py-4 hover:bg-slate-50/80 transition flex items-start gap-4",
                      selected?.id === lead.id && "bg-gold/5 border-r-4 border-gold"
                    )}
                  >
                    <div className="w-10 h-10 rounded-full bg-navy/10 flex items-center justify-center text-navy font-semibold shrink-0">
                      {lead.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-medium text-navy truncate">{lead.name}</p>
                        <span className="text-xs text-slate-400 shrink-0">
                          {formatRelative(lead.createdAt)}
                        </span>
                      </div>
                      <p className="text-sm text-slate-500 mt-0.5">
                        {lead.service} · {lead.phone}
                      </p>
                      {st && (
                        <span className={`inline-block mt-1.5 text-xs px-2 py-0.5 rounded-full ${st.color}`}>
                          {st.label}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Detail panel */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 sticky top-6">
          {!selected ? (
            <div className="h-64 flex items-center justify-center text-slate-400 text-sm">
              یک درخواست را انتخاب کنید
            </div>
          ) : (
            <div className="space-y-5">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-bold text-navy">{selected.name}</h3>
                  <p className="text-sm text-slate-500">{selected.service}</p>
                </div>
                <button
                  onClick={() => deleteLead(selected.id)}
                  className="text-red-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-red-50 transition"
                  title="حذف"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-slate-600">
                  <Phone size={15} className="text-slate-400" />
                  <a href={`tel:${selected.phone}`} className="hover:text-navy" dir="ltr">
                    {selected.phone}
                  </a>
                </div>
                {selected.email && (
                  <div className="flex items-center gap-2 text-slate-600">
                    <Mail size={15} className="text-slate-400" />
                    <a href={`mailto:${selected.email}`} className="hover:text-navy">
                      {selected.email}
                    </a>
                  </div>
                )}
                <div className="text-xs text-slate-400">
                  ثبت‌شده در {formatDate(selected.createdAt)}
                </div>
              </div>

              {selected.message && (
                <div className="bg-slate-50 rounded-xl p-3">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                    <MessageSquare size={13} />
                    پیام
                  </div>
                  <p className="text-sm text-slate-700">{selected.message}</p>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">وضعیت</label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-gold/40"
                >
                  {statusOptions.map((s) => (
                    <option key={s.value} value={s.value}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  یادداشت داخلی
                </label>
                <textarea
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  rows={4}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-gold/40 resize-none"
                  placeholder="یادداشت‌های خود را اینجا بنویسید..."
                />
              </div>

              <button
                onClick={saveLead}
                disabled={saving}
                className="w-full flex items-center justify-center gap-2 bg-navy hover:bg-slate-800 text-white py-2.5 rounded-xl text-sm font-medium transition disabled:opacity-60"
              >
                <Save size={16} />
                {saving ? "در حال ذخیره..." : "ذخیره تغییرات"}
              </button>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
