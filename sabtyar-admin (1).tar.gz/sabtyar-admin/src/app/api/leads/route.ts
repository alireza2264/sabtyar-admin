import { NextRequest, NextResponse } from "next/server";
import { getLeads, addLead, getStats } from "@/lib/leads-store";

// GET all leads or stats
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  if (searchParams.get("stats") === "1") {
    return NextResponse.json(getStats());
  }
  return NextResponse.json(getLeads());
}

// POST new lead (from website forms)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, phone, email, service, message } = body;

    if (!name || !phone) {
      return NextResponse.json(
        { error: "نام و شماره تماس الزامی است" },
        { status: 400 }
      );
    }

    const lead = addLead({
      name: String(name).trim(),
      phone: String(phone).trim(),
      email: email ? String(email).trim() : undefined,
      service: service ? String(service).trim() : "عمومی",
      message: message ? String(message).trim() : undefined,
    });

    return NextResponse.json({ success: true, lead }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "خطای سرور" }, { status: 500 });
  }
}
