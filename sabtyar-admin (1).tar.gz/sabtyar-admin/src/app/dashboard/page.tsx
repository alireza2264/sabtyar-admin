"use client";

import { useEffect, useState } from "react";
import AdminLayout from "@/components/AdminLayout";
import { Users, UserPlus, Phone, CheckCircle, Clock } from "lucide-react";
import { formatRelative } from "@/lib/utils";
import Link from "next/link";

interface Stats {
  total: number;
  new: number;
  contacted: number;
  in_progress: number;
  closed: number;
}

interface Lead {
  id: string;
  name: string;
  phone: string;
  service: string;
  status: string;
  createdAt: string;
}

const statusMap: Record<string, { label: string; color: string }> = {
  new: { label: "جدید", color: "bg-blue-100 text-blue-700" },
  contacted: { label: "تماس گرفته شده", color: "bg-amber-100 text-amber-700" },
  in_progress: { label: "در حال پیگیری", color: "bg-purple-100 text-purple-700" },
  closed: { label: "بسته شده", color: "bg-green-100 text-green-700" },
  spam: { label: "اسپم", color: "bg-red-100 text-red-700" },
};

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [recent, setRecent] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/leads?stats=1").then((r) => r.json()),
      fetch("/api/leads").then((r) => r.json()),
    ]).then(([s, leads]) => {
      setStats(s);
      setRecent(leads.slice(0, 5));
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64 text-slate-400">
          در حال بارگذاری...
        </div>
      </AdminLayout>
    );
  }

  const cards = [
    { label: "کل درخواست‌ها", value: stats?.total ?? 0, icon: Users, color: "bg-navy" },
    { label: "جدید", value: stats?.new ?? 0, icon: UserPlus, color: "bg-blue-600" },
    { label: "تماس گرفته شده", value: stats?.contacted ?? 0, icon: Phone, color: "bg-amber-500" },
    { label: "در حال پیگیری", value: stats?.in_progress ?? 0, icon: Clock, color: "bg-purple-600" },
    { label: "بسته شده", value: stats?.closed ?? 0, icon: CheckCircle, color: "bg-green-600" },
  ];

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-navy">داشبورد</h1>
        <p className="text-slate-500 mt-1">خلاصه وضعیت درخواست‌ها</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">{card.label}</p>
                  <p className="text-2xl font-bold text-navy mt-1">{card.value}</p>
                </div>
                <div className={`w-11 h-11 rounded-xl ${card.color} flex items-center justify-center`}>
                  <Icon className="text-white" size={20} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="font-semibold text-navy">آخرین درخواست‌ها</h2>
          <Link
            href="/leads"
            className="text-sm text-gold hover:text-navy transition"
          >
            مشاهده همه ←
          </Link>
        </div>
        <div className="divide-y divide-slate-50">
          {recent.length === 0 ? (
            <div className="p-8 text-center text-slate-400">هنوز درخواستی ثبت نشده</div>
          ) : (
            recent.map((lead) => (
              <div
                key={lead.id}
                className="px-6 py-4 flex items-center justify-between hover:bg-slate-50/50 transition"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-navy/10 flex items-center justify-center text-navy font-medium">
                    {lead.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-medium text-navy">{lead.name}</p>
                    <p className="text-sm text-slate-500">
                      {lead.service} · {lead.phone}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span
                    className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                      statusMap[lead.status]?.color || "bg-slate-100 text-slate-600"
                    }`}
                  >
                    {statusMap[lead.status]?.label || lead.status}
                  </span>
                  <span className="text-xs text-slate-400 hidden sm:block">
                    {formatRelative(lead.createdAt)}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
