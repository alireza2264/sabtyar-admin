import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "پنل مدیریت | ثبت یار هوشمند",
  description: "پنل مدیریت حرفه‌ای ثبت یار هوشمند",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-paper text-ink antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
