"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  FileText,
  LogOut,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";

const links = [
  { href: "/dashboard", label: "داشبورد", icon: LayoutDashboard },
  { href: "/leads", label: "درخواست‌ها", icon: Users },
  { href: "/content", label: "محتوای سایت", icon: FileText },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    await fetch("/api/auth", { method: "DELETE" });
    router.push("/login");
  }

  return (
    <aside className="fixed right-0 top-0 h-screen w-64 bg-navy text-white flex flex-col z-50">
      <div className="p-6 border-b border-white/10">
        <h1 className="text-lg font-bold text-gold-soft">ثبت یار هوشمند</h1>
        <p className="text-xs text-white/50 mt-1">پنل مدیریت</p>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {links.map((link) => {
          const Icon = link.icon;
          const active = pathname === link.href || pathname.startsWith(link.href + "/");
          return (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition",
                active
                  ? "bg-gold/20 text-gold-soft"
                  : "text-white/70 hover:bg-white/5 hover:text-white"
              )}
            >
              <Icon size={18} />
              {link.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/10">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-white/70 hover:bg-white/5 hover:text-white w-full transition"
        >
          <LogOut size={18} />
          خروج
        </button>
      </div>
    </aside>
  );
}
